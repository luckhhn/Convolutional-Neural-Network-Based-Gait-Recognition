from sklearn.externals import joblib
import glob as gb
from tqdm import tqdm
import numpy as np
from sklearn.model_selection import train_test_split, ShuffleSplit
import tensorflow as tf
from keras.utils import to_categorical
from sklearn.externals import joblib
import matplotlib.pyplot as plt
import math

X_train_orig = joblib.load('X_train_official_casia_b_originalsize_flatten_all.pkl')
Y_train_orig = joblib.load('Y_train_orig_official_casia_b_originalsize_flatten_all.pkl')
print("=========================================================")
print("X_train_orig.shape", X_train_orig.shape)
print("Y_train_orig.shape", Y_train_orig.shape)

###########################
input_size_x = 240
input_size_y = 240
placeholder_size = input_size_x * input_size_y
number_of_subjects = 124
num_epoch = 500
minibatch_size = 64
learning_rate = 1e-5
dropout_keep_ratio = 0.5
no_dropout = 1
test_set_ratio = 0.25
validation_set_index = 7
X_train, X_test, Y_train, Y_test = train_test_split(X_train_orig, Y_train_orig, test_size=test_set_ratio,
                                                    random_state=1)

Y_train = to_categorical(Y_train)
Y_train = np.delete(Y_train, 0, 1)
Y_test = to_categorical(Y_test)
Y_test = np.delete(Y_test, 0, 1)
print("=========================================================")
print("X_train.shape", X_train.shape)
print("X_test.shape", X_test.shape)
print("=========================================================")
print("Y_train(after one hot).shape", Y_train.shape)
print("Y_test(after one hot).shape", Y_test.shape)
print("=========================================================")


def next_batch(data, label_, size):
    data_list = []
    label_list = []
    for b in range(math.ceil(data.shape[0] / size)):
        head = ((b * size) % data.shape[0])
        tail = min((head + size), data.shape[0])
        # print('Batch(%d)' % (i + 1), head, tail)
        data_list.append(data[head:tail, :])
        label_list.append(label_[head:tail, :])
    return data_list, label_list


iteration = round(X_train.shape[0] / minibatch_size) * num_epoch
print("1 epoch = ", X_train.shape[0] / minibatch_size, "iteration")
print("Number of iteration:", iteration)
print("%d epoch in total:" % num_epoch)
print("=========================================================")
Xtrain_batch, Ytrain_batch = next_batch(X_train, Y_train, minibatch_size)
print("len(Xtrain_batch)", len(Xtrain_batch))
print("len(Ytrain_batch.shape)", len(Ytrain_batch))
print("=========================================================")
Xtest_batch, Ytest_batch = next_batch(X_test, Y_test, minibatch_size)
print("len(Xtest_batch)", len(Xtest_batch))
print("len(Ytest_batch)", len(Ytest_batch))
print("=========================================================")
Xvalidation_set = Xtrain_batch[7]
Yvalidation_set = Ytrain_batch[7]
print("Batch %d is validation set" % validation_set_index)
print("=========================================================")

sess = tf.InteractiveSession()
x = tf.placeholder("float32", [None, placeholder_size])
y_ = tf.placeholder("float32", [None, number_of_subjects])


def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)


def bias_variable(shape):
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)


def conv2d(x, W):
    return tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='SAME')


def max_pool_2x2(x):
    return tf.nn.max_pool(x, ksize=[1, 2, 2, 1],
                          strides=[1, 2, 2, 1], padding='SAME')


W_conv1 = weight_variable([5, 5, 1, 32])
b_conv1 = bias_variable([32])

x_image = tf.reshape(x, [-1, input_size_x, input_size_y, 1])
h_conv1 = tf.nn.relu(conv2d(x_image, W_conv1) + b_conv1)
h_pool1 = max_pool_2x2(h_conv1)

W_conv2 = weight_variable([5, 5, 32, 64])
b_conv2 = bias_variable([64])

h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2) + b_conv2)
h_pool2 = max_pool_2x2(h_conv2)

W_fc1 = weight_variable([round(input_size_x / 4) * round(input_size_y / 4) * 64, 1024])
b_fc1 = bias_variable([1024])

h_pool2_flat = tf.reshape(h_pool2, [-1, round(input_size_x / 4) * round(input_size_y / 4) * 64])
h_fc1 = tf.nn.relu(tf.matmul(h_pool2_flat, W_fc1) + b_fc1)

keep_prob = tf.placeholder("float")
h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

W_fc2 = weight_variable([1024, 124])
b_fc2 = bias_variable([124])

y_conv = tf.nn.softmax(tf.matmul(h_fc1_drop, W_fc2) + b_fc2)

cross_entropy = -tf.reduce_sum(y_ * tf.log(tf.clip_by_value(y_conv, 1e-8, 1.0)))
train_step = tf.train.AdamOptimizer(learning_rate).minimize(cross_entropy)
correct_prediction = tf.equal(tf.argmax(y_conv, 1), tf.argmax(y_, 1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))
sess.run(tf.initialize_all_variables())

# for loop in range(10):
train_accuracy_list = []
validation_accuracy_list = []
train_cross_entropy_list = []
validation_cross_entropy_list = []
for iteration in tqdm(range(iteration)):
    index = iteration % len(Xtrain_batch)
    if iteration % round(X_train.shape[0] / minibatch_size) == 0:
        train_cross_entropy = cross_entropy.eval(feed_dict={
            x: Xtrain_batch[index], y_: Ytrain_batch[index], keep_prob: no_dropout})
        print("Iteration %d, train_cross_entropy %g" % (iteration, train_cross_entropy))
        train_cross_entropy_list.append(train_cross_entropy)

        validation_cross_entropy = cross_entropy.eval(feed_dict={
            x: Xvalidation_set, y_: Yvalidation_set, keep_prob: no_dropout})
        print("validation_cross_entropy %g" % validation_cross_entropy)
        validation_cross_entropy_list.append(validation_cross_entropy)

        train_accuracy = accuracy.eval(feed_dict={
            x: Xtrain_batch[index], y_: Ytrain_batch[index], keep_prob: no_dropout})
        print("training accuracy %g" % train_accuracy)
        train_accuracy_list.append(train_accuracy)

        validation_accuracy = accuracy.eval(feed_dict={
            x: Xvalidation_set, y_: Yvalidation_set, keep_prob: no_dropout})
        print("validation_accuracy %g" % validation_accuracy)
        validation_accuracy_list.append(validation_accuracy)
    ##############################################################################
    train_step.run(feed_dict={x: Xtrain_batch[index], y_: Ytrain_batch[index], keep_prob: dropout_keep_ratio})
    ##############################################################################

print("Test Accuracy %g" % accuracy.eval(feed_dict={
    x: X_test, y_: Y_test, keep_prob: no_dropout}))
print("Test cross_entropy %g" % cross_entropy.eval(feed_dict={
    x: X_test, y_: Y_test, keep_prob: no_dropout}))

fig = plt.figure(figsize=(15, 15))
ax1 = fig.add_subplot(211)
x = range(num_epoch)
p1, = ax1.plot(x, train_cross_entropy_list, "ro", label="Train Cross Entropy")
p2, = ax1.plot(x, validation_cross_entropy_list, "bo", label="Validation Cross Entropy")
handles, labels = ax1.get_legend_handles_labels()
ax1.set_ylabel('Cross Entropy')
ax1.set_xlabel('Epoch')
ax1.set_title(" Cross_entropy|Learning rate =" + str(learning_rate) + "| Last Train Cross Entropy:" +
              str(train_cross_entropy_list[-1]) +
              "| Last Validation Cross Entropy:" + str(validation_cross_entropy_list[-1]))
ax1.legend(handles[::-1], labels[::-1])

ax2 = fig.add_subplot(212)
p3, = ax2.plot(x, train_accuracy_list, "ro", label="Train Accuracy")
p4, = ax2.plot(x, validation_accuracy_list, "bo", label="Validation Accuracy")
handles1, labels1 = ax1.get_legend_handles_labels()
ax2.set_ylabel('Accuracy')
ax2.set_xlabel('Epoch')
ax2.set_title(
    " Accuracy|Learning rate =" + str(learning_rate) + "| Last Train Accuracy:" + str(train_accuracy_list[-1]) +
    "| Last Validation Accuracy:" + str(validation_accuracy_list[-1]))
ax2.legend(handles1[::-1], labels1[::-1])
plt.show()
