# -*- coding: utf-8 -*-
"""
Created on 2 Aug 2018

@author: Yuhao Ye
"""
import argparse
import logging
import sys
from tf_pose import common
import numpy as np
from tf_pose.estimator import TfPoseEstimator
from tf_pose.networks import get_graph_path, model_wh
from lifting.prob_model import Prob3dPose
from lifting.draw import plot_pose
import ffmpeg
import matplotlib.pyplot as plt
import os
from sklearn.externals import joblib
import glob as gb
import time
import cv2
import os
from tqdm import tqdm
import math
import datetime
import math

img_matrix = joblib.load('/mainfs/scratch/yy2u17/video_dump/casia_b_video_90degree_30frames_frame_matrix.pkl')
print(img_matrix.shape)
#
width = 320
height = 240


#
#
def openpose(img1, model):
    humans1 = model.inference(img1, upsample_size=4.0)
    return humans1


def unit_vector(vector):
    """ Returns the unit vector of the vector.  """
    return vector / np.linalg.norm(vector)


def angle_between(v1, v2):
    """ Returns the angle in radians between vectors 'v1' and 'v2'::

            >>> angle_between((1, 0, 0), (0, 1, 0))
            1.5707963267948966
            >>> angle_between((1, 0, 0), (1, 0, 0))
            0.0
            >>> angle_between((1, 0, 0), (-1, 0, 0))
            3.141592653589793
    """
    v1_u = unit_vector(v1)
    v2_u = unit_vector(v2)
    return np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0))


num_of_frame = 30
knee_degree_left = np.zeros((1240, num_of_frame))
knee_degree_right = np.zeros((1240, num_of_frame))
noise_height_matrix = np.zeros((1240, num_of_frame))
left_shoulder_height_matrix = np.zeros((1240, num_of_frame))
right_upper_leg_length_matrix = np.zeros((1240, num_of_frame))
right_lower_leg_length_matrix = np.zeros((1240, num_of_frame))
left_upper_leg_length_matrix = np.zeros((1240, num_of_frame))
left_lower_leg_length_matrix = np.zeros((1240, num_of_frame))
right_upper_leg_length_feature = np.zeros((1240, 5))
right_lower_leg_length_feature = np.zeros((1240, 5))
left_upper_leg_length_feature = np.zeros((1240, 5))
left_lower_leg_length_feature = np.zeros((1240, 5))
count = 0
e = TfPoseEstimator(get_graph_path('cmu'), target_size=(width, height))
for i in tqdm(range(img_matrix.shape[0])):
    print("No:", i)
    start_time = datetime.datetime.now()
    for j in range(img_matrix.shape[1]):
        img = img_matrix[i, j, :, :, :]
        humans = openpose(img, e)
        # Right Hip No.8
        if str(humans).find('8-') == -1:
            RHip_x = 0
            RHip_y = 0
        else:
            RHip_x = round(float(str(humans)[str(humans).find('8-') + 3:str(humans).find('8-') + 7]) * 320)
            RHip_y = round(float(str(humans)[str(humans).find('8-') + 9:str(humans).find('8-') + 13]) * 240)
        # Right Knee No.9
        if str(humans).find('9-') == -1:
            RKnee_x = 0
            RKnee_y = 0
        else:
            RKnee_x = round(float(str(humans)[str(humans).find('9-') + 3:str(humans).find('9-') + 7]) * 320)
            RKnee_y = round(float(str(humans)[str(humans).find('9-') + 9:str(humans).find('9-') + 13]) * 240)
        # Right Ankle No.10
        if str(humans).find('10-') == -1:
            RAnkle_x = 0
            RAnkle_y = 0
        else:
            RAnkle_x = round(float(str(humans)[str(humans).find('10-') + 4:str(humans).find('10-') + 8]) * 320)
            RAnkle_y = round(float(str(humans)[str(humans).find('10-') + 10:str(humans).find('10-') + 14]) * 240)

        ############################################################################
        right_upper_leg_length = math.hypot((RHip_x - RKnee_x), (RHip_y - RKnee_y))
        right_lower_leg_length = math.hypot((RAnkle_x - RKnee_x), (RAnkle_y - RKnee_y))
        ############################################################################
        # Left Hip No. 11
        if str(humans).find('11-') == -1:
            LHip_x = 0
            LHip_y = 0
        else:
            LHip_x = round(float(str(humans)[str(humans).find('11-') + 4:str(humans).find('11-') + 8]) * 320)
            LHip_y = round(float(str(humans)[str(humans).find('11-') + 10:str(humans).find('11-') + 14]) * 240)
        # Left Knee No.12
        if str(humans).find('12-') == -1:
            LKnee_x = 0
            LKnee_y = 0
        else:
            LKnee_x = round(float(str(humans)[str(humans).find('12-') + 4:str(humans).find('12-') + 8]) * 320)
            LKnee_y = round(float(str(humans)[str(humans).find('12-') + 10:str(humans).find('12-') + 14]) * 240)
        # Left Ankle No.13
        if str(humans).find('13-') == -1:
            LAnkle_x = 0
            LAnkle_y = 0
        else:
            LAnkle_x = round(float(str(humans)[str(humans).find('13-') + 4:str(humans).find('13-') + 8]) * 320)
            LAnkle_y = round(float(str(humans)[str(humans).find('13-') + 10:str(humans).find('13-') + 14]) * 240)
        ############################################################################
        left_upper_leg_length = math.hypot((LHip_x - LKnee_x), (LHip_y - LKnee_y))
        left_lower_leg_length = math.hypot((LAnkle_x - LKnee_x), (LAnkle_y - LKnee_y))
        ############################################################################
        # Nose No.0
        if str(humans).find('0-') == -1:
            Nose_y = 0
        else:
            Nose_y = round(float(str(humans)[str(humans).find('0-') + 9:str(humans).find('0-') + 13]) * 240)
        # LShoulder No.5
        if str(humans).find('5-') == -1:
            LShoulder_y = 0
        else:
            LShoulder_y = round(float(str(humans)[str(humans).find('5-') + 9:str(humans).find('5-') + 13]) * 240)
        x1 = np.array([LHip_x - LKnee_x, LHip_y - LKnee_y])
        x2 = np.array([LAnkle_x - LKnee_x, LAnkle_y - LKnee_y])
        x3 = np.array([RHip_x - RKnee_x, RHip_y - RKnee_y])
        x4 = np.array([RAnkle_x - RKnee_x, RAnkle_y - RKnee_y])
        degree_left = np.degrees(angle_between(x1, x2))
        degree_right = np.degrees(angle_between(x3, x4))
        # print(degree_left)
        # print(degree_right)
        # print(Nose_y)
        # print(LShoulder_y)
        right_upper_leg_length_matrix[i, j] = right_upper_leg_length
        right_lower_leg_length_matrix[i, j] = right_lower_leg_length
        left_upper_leg_length_matrix[i, j] = left_upper_leg_length
        left_lower_leg_length_matrix[i, j] = left_lower_leg_length
        knee_degree_left[i, j] = degree_left
        knee_degree_right[i, j] = degree_right
        noise_height_matrix[i, j] = Nose_y
        left_shoulder_height_matrix[i, j] = LShoulder_y
    end_time = datetime.datetime.now()
    print("This video spend: ", (end_time - start_time).seconds)
for i in range(right_upper_leg_length_matrix.shape[0]):
    for j in range(right_upper_leg_length_matrix.shape[1]):
        if j != 0:
            if right_upper_leg_length_matrix[i][j] > 100:
                right_upper_leg_length_matrix[i][j] = right_upper_leg_length_matrix[i][j - 1]
            if right_lower_leg_length_matrix[i][j] > 100:
                right_lower_leg_length_matrix[i][j] = right_lower_leg_length_matrix[i][j - 1]
            if left_upper_leg_length_matrix[i][j] > 100:
                left_upper_leg_length_matrix[i][j] = left_upper_leg_length_matrix[i][j - 1]
            if left_lower_leg_length_matrix[i][j] > 100:
                left_lower_leg_length_matrix[i][j] = left_lower_leg_length_matrix[i][j - 1]
    right_upper_leg_length_mean = np.mean(right_upper_leg_length_matrix[i, :])
    right_lower_leg_length_mean = np.mean(right_lower_leg_length_matrix[i, :])
    left_upper_leg_length_mean = np.mean(left_upper_leg_length_matrix[i, :])
    left_lower_leg_length_mean = np.mean(left_lower_leg_length_matrix[i, :])
    for a in range(5):
        right_upper_leg_length_feature[i, a] = right_upper_leg_length_mean
        right_lower_leg_length_feature[i, a] = right_lower_leg_length_mean
        left_upper_leg_length_feature[i, a] = left_upper_leg_length_mean
        left_lower_leg_length_feature[i, a] = left_lower_leg_length_mean

feature_matrix = np.column_stack(
    (knee_degree_left, knee_degree_right, noise_height_matrix, left_shoulder_height_matrix,
     right_upper_leg_length_feature, right_lower_leg_length_feature, left_upper_leg_length_feature,
     left_lower_leg_length_feature))
print(feature_matrix.shape)
joblib.dump(feature_matrix, 'double_side_knee_angle_head_shoulder_double_leg_length_mean_matrix_30.pkl')
