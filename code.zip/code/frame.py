import cv2
import os
from tqdm import tqdm
import datetime
import matplotlib.pyplot as plt
from sklearn.externals import joblib
import numpy as np

rootDir = '/mainfs/scratch/yy2u17/videos/'
print(len('/mainfs/scratch/yy2u17/videos/001-bg-01-000.avi'))
path_list = []
label_list = []
frames = 30


# count the number of foreground pixels in
# the silhouette in each frame over time
def pixels_sum(image, height, width):
    sum1 = 0
    for heights in range(height):
        for widths in range(width):
            if image[heights, widths] == 255:
                sum1 += 1
    return sum1


def select_gait_period(silhouette11_list):
    # Initialize variables
    foreground_pixels_list = []
    gait_period_flag_value_list = []
    gait_period_flag_list = []
    one_gait_period_img_list = []
    gait_period_flag_real_index_list = []
    # For calculating and selecting one gait period frames
    for index1 in range(len(silhouette11_list)):
        img = silhouette11_list[index1]
        foreground_pixels = pixels_sum(img, img.shape[0], img.shape[1])
        foreground_pixels_list.append(foreground_pixels)
    for d in range(len(foreground_pixels_list) - 5):
        if foreground_pixels_list[d + 3] < foreground_pixels_list[d + 2] and foreground_pixels_list[d + 3] < \
                foreground_pixels_list[d + 1] and foreground_pixels_list[d + 3] < foreground_pixels_list[d + 4] and \
                foreground_pixels_list[d + 3] < foreground_pixels_list[d + 5]:
            gait_period_flag_value_list.append(foreground_pixels_list[d + 3])
            gait_period_flag_list.append(d)
    for e in range(len(gait_period_flag_value_list)):
        gait_period_flag_real_index_list.append(gait_period_flag_list[e] + 3)
    print("gait_period_flag_list", gait_period_flag_list)
    # if len(gait_period_flag_list) > 5:
    #     period_length = ((gait_period_flag_list[5]) - gait_period_flag_list[2])
    # else:
    #     period_length = ((gait_period_flag_list[3]) - gait_period_flag_list[0])
    # return gait_period_flag_list, period_length
    return gait_period_flag_list


def path_generator(rootDir):
    count = 0
    for root, dirs, files in os.walk(rootDir, topdown=False):
        for name in files:
            # print(os.path.join(root, name), os.path.join(root, name)[41])
            if os.path.join(root, name)[35] != "k" and os.path.join(root, name)[41] == '9':
                count += 1
                # print(os.path.join(root, name))
                label_list.append(int(os.path.join(root, name)[30:33]))
                path_list.append(os.path.join(root, name))
                # print(os.path.join(root, name), )
    print(count, "Gait Videos in Total")


frame_matrix = np.zeros((1240, 30, 240, 320, 3))
path_generator(rootDir)
# period_length_list = []
for i in range(len(path_list)):
    print(path_list[i], label_list[i])
for i in tqdm(range(len(path_list))):
    start_time = datetime.datetime.now()
    print("No.", i)
    video_path = path_list[i]
    print(video_path)
    vc = cv2.VideoCapture(video_path)  # 读入视频文件
    c = 1
    if vc.isOpened():  # 判断是否正常打开
        rval, frame = vc.read()
        print("Read Successfully")
    else:
        rval = False
    count = 0
    name_no = 0
    total_frame_list = []
    silhouette1_list = []
    while rval:  # 循环读取视频帧
        rval, frame = vc.read()
        count += 1
        total_frame_list.append(frame)
    vc.release()
    print("len(total_frame_list)", len(total_frame_list))
    background = total_frame_list[0]
    for index in range(len(total_frame_list) - 1):
        name_no += 1
        frame_temp = total_frame_list[index]
        subtraction_back_frame = cv2.subtract(background, frame_temp)
        subtraction_back_frame = cv2.cvtColor(subtraction_back_frame, cv2.COLOR_BGR2GRAY)  # Gray scale
        ret1, silhouette1 = cv2.threshold(subtraction_back_frame, 37, 255, cv2.THRESH_BINARY)
        silhouette1_list.append(silhouette1)
    # one_gait_period_index_list, period_length1 = select_gait_period(silhouette1_list)
    one_gait_period_index_list = select_gait_period(silhouette1_list)
    # period_length_list.append(period_length1)
    if len(one_gait_period_index_list) > 5:
        one_gait_period_frame = total_frame_list[
                                one_gait_period_index_list[1] + 3:one_gait_period_index_list[1] + 3 + frames]
    else:
        one_gait_period_frame = total_frame_list[
                                one_gait_period_index_list[0] + 3:one_gait_period_index_list[0] + 3 + frames]
    for index2 in range(len(one_gait_period_frame)):
        cut = one_gait_period_frame[index2]
        frame_matrix[i, index2, :, :, :] = cut
        # cv2.imwrite(
        #     '/mainfs/scratch/yy2u17/test_out/' + video_path[30:39] + '_' + str(index2) + "(" + str(
        #         len(total_frame_list)) + ")" + '.png',
        #     cut)
    end_time = datetime.datetime.now()
    print("This video spend: ", (end_time - start_time).seconds, "seconds")

joblib.dump(label_list, 'casia_b_video_90degree_30frames_label_list.pkl')
joblib.dump(frame_matrix, 'casia_b_video_90degree_30frames_frame_matrix.pkl')
