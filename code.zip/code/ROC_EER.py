import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.externals import joblib

class_intra = []
class_inter = []
softmax_out = joblib.load("V4_cut_leg_softmax_result_matrix.pkl")
label = joblib.load("V4_cut_leg_Y_test.pkl")
print(softmax_out.shape)
print(label.shape)
# print(label[0])
# print(np.argmax(label[0], 0))
label = np.argmax(label, 1)
print(label.shape)
print(label)

for i in range(softmax_out.shape[0]):
    for j in range(softmax_out.shape[1]):
        # 需要识别的用户id和模型id一样，就认为是类内测试，否则是类间测试
        if j == label[i]:
            class_intra.append(softmax_out[i][j])
        else:
            class_inter.append(softmax_out[i][j])
FRR = []
FAR = []
thresld = np.arange(0, 1.01, 0.01)  # 生成模型阈值的等差列表
print(thresld)
eer = 1
for i in range(len(thresld)):
    frr = np.sum(class_intra < thresld[i]) / len(class_intra)
    FRR.append(frr)

    far = np.sum(class_inter > thresld[i]) / len(class_inter)
    FAR.append(far)

    if abs(frr - far) < 0.02:  # frr和far值相差很小时认为相等
        eer = abs(frr + far) / 2

plt.plot(thresld, FRR, 'x-', label='FRR')
plt.plot(thresld, FAR, '+-', label='FAR')
plt.grid(True)
plt.legend(bbox_to_anchor=(1.0, 1), loc=1, borderaxespad=0.)
plt.show()
print('EER is: ', eer)
eer = eer * 100
# plt.plot(x, y, label='EER')
# FAR = FAR * 100
# FRR = FRR * 100
plt.plot(FAR, FRR, 'x-', label='ROC')
plt.xlabel("False Acceptance Rate", fontsize=15)
plt.ylabel("False Rejection Rate", fontsize=15)
plt.legend(bbox_to_anchor=(1.0, 1), loc=1, borderaxespad=0.)
plt.title("Receiver operating characteristic(ROC) Curve " + "EER:%.2f" % eer + "%")
plt.grid(True)
plt.show()
