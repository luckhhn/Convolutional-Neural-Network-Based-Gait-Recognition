import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.externals import joblib

#
# predict_label = pd.read_csv('softmax_result_matrix.csv')  # 这里以结果在csv文件为例
# predict_label = np.array(predict_label)
predict_label = joblib.load("V4_cut_leg_softmax_result_matrix.pkl")
test_y = joblib.load("V4_cut_leg_Y_test.pkl")
print(predict_label.shape)
print(test_y.shape)
# CMC曲线
# 需要提供predict_label和test_y这两个变量
# 需要安装numpy和matplotlib这两个包
test_cmc = []  # 保存accuracy，记录rank1到rank48的准确率
sort_index = np.argsort(-predict_label, axis=1)  # predict_label为模型预测得到的匹配分数矩阵；降序排序，返回匹配分数值从大到小的索引值

actual_index = np.argmax(test_y, 1)  # test_y为测试样本的真实标签矩阵；返回一列真实标签相对应的最大值的索引值
predict_index = np.argmax(predict_label, 1)  # 返回一列预测标签相对应的最大值的索引值
temp = np.cast['float32'](np.equal(actual_index, predict_index))  # 一列相似值，1代表相同，0代表不同
test_cmc.append(np.mean(temp))  # rank1
# rank2到rank48
for i in range(sort_index.shape[1] - 1):
    for j in range(len(temp)):
        if temp[j] == 0:
            predict_index[j] = sort_index[j][i + 1]
    temp = np.cast['float32'](np.equal(actual_index, predict_index))
    test_cmc.append(np.mean(temp))
# 创建绘图对象
flag = 0
index = 0
for i in range(len(test_cmc)):
    if flag == 0 and test_cmc[i]*100 == 100:
        index = i
        flag = 1

print(index)
print(test_cmc[0])
plt.figure()
x = np.arange(0, sort_index.shape[1])
plt.plot(x, test_cmc, color="red", linewidth=2)

plt.xlabel("Rank", fontsize=14)
plt.ylabel("Correct Classification Rates", fontsize=14)
plt.title("Cumulative Match Characteristic Curve (CMC)")
plt.show()
