#!/lyceum/yy2u17/.conda/envs/tensorflow_gpu/bin/python
# SBATCH --job-name=vgg16_decay
# SBATCH --time=24:00:00
# SBATCH --gres=gpu:1
# SBATCH -p lyceum
from sklearn.externals import joblib
import glob as gb
from tqdm import tqdm
import numpy as np
from sklearn.model_selection import train_test_split, ShuffleSplit
import tensorflow as tf
from keras.utils import to_categorical
from sklearn.externals import joblib
import matplotlib.pyplot as plt
import math
import os
from tensorflow_vgg import vgg16
from tensorflow_vgg import utils

# X_train = joblib.load('/mainfs/scratch/yy2u17/cifar10/X_train_224_padding_noflatten.pkl')
# X_test = joblib.load('/mainfs/scratch/yy2u17/cifar10/X_test_224_padding_noflatten.pkl')
X_train = joblib.load('/mainfs/scratch/yy2u17/CASIA_B/X_train_official_casia_b_resize224_noflatten_all.pkl')

###########################
input_size_x = 224
input_size_y = 224
channel = 3
minibatch_size = 32
###########################
print("=========================================================")
print("X_train.shape", X_train.shape)
# print("X_test.shape", X_test.shape)
print("=========================================================")


def next_batch(data, size):
    data_list = []
    for i in range(math.ceil(data.shape[0] / size)):
        head = ((i * size) % data.shape[0])
        tail = min((head + size), data.shape[0])
        data_list.append(data[head:tail, :, :, :])
    print("Last batch:", head, tail)
    return data_list


print("=========================================================")
Xtrain_batch = next_batch(X_train, minibatch_size)
print("len(Xtrain_batch)", len(Xtrain_batch))
print("=========================================================")

sess = tf.InteractiveSession()

vgg = vgg16.Vgg16()
input_ = tf.placeholder(tf.float32, [None, 224, 224, 3])
with tf.name_scope("content_vgg"):
    vgg.build(input_)
#########################################################################################
bottlenect_feature_train = None
bottlenect_feature_test = None
#########################################################################################
for i in tqdm(range(len(Xtrain_batch))):
    print(i)
    # print(Xtrain_batch[i].shape)
    a = Xtrain_batch[i]
    feed_dict = {input_: a}
    codes_batch = sess.run(vgg.relu6, feed_dict=feed_dict)
    if bottlenect_feature_train is None:
        bottlenect_feature_train = codes_batch
    else:
        bottlenect_feature_train = np.concatenate((bottlenect_feature_train, codes_batch))
#########################################################################################
# for i in tqdm(range(len(Xtest_batch))):
#     print(i)
#     # print(Xtrain_batch[i].shape)
#     a = Xtest_batch[i]
#     feed_dict = {input_: a}
#     codes_batch = sess.run(vgg.relu6, feed_dict=feed_dict)
#     if bottlenect_feature_test is None:
#         bottlenect_feature_test = codes_batch
#     else:
#         bottlenect_feature_test = np.concatenate((bottlenect_feature_test, codes_batch))
#########################################################################################
joblib.dump(bottlenect_feature_train, 'bottlenect_feature_resize_train.pkl')

# print(i)
# print(type(bottlenect_feature))
# print(bottlenect_feature.shape)
# print(bottlenect_feature[0, :])
