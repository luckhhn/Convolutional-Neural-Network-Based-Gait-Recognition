# -*- coding: utf-8 -*-
__author__ = 'Administrator'

# import packages
from keras.preprocessing.image import ImageDataGenerator, array_to_img, img_to_array, load_img
# import cv2
# from PIL import Image
datagen = ImageDataGenerator(
    rotation_range=360,
    horizontal_flip=True,
    fill_mode='constant')

# rotation_range: 旋转范围, 随机旋转(0-180)度;
# width_shift and height_shift: 随机沿着水平或者垂直方向，以图像的长宽小部分百分比为变化范围进行平移;
# rescale: 对图像按照指定的尺度因子, 进行放大或缩小, 设置值在0 - 1之间，通常为1 / 255;
# shear_range: 水平或垂直投影变换, 参考这里 https://keras.io/preprocessing/image/
# zoom_range: 按比例随机缩放图像尺寸;
# horizontal_flip: 水平翻转图像;
# fill_mode: 填充像素, 出现在旋转或平移之后．
img = load_img(
    '/mainfs/scratch/yy2u17/CASIA_B/GEI_CASIA_B/001/bg-01/001-bg-01-090.png')  # this is a PIL image, please replace to your own file path
x = img_to_array(img)  # this is a Numpy array with shape (3, 150, 150)
x = x.reshape((1,) + x.shape)  # this is a Numpy array with shape (1, 3, 150, 150)

# the .flow() command below generates batches of randomly transformed images
# and saves the results to the `preview/` directory
img_list = []
i = 0
for batch in datagen.flow(x,
                          batch_size=1,
                          save_to_dir='/mainfs/scratch/yy2u17/CASIA_B/augmentation_out/',  # 生成后的图像保存路径
                          save_prefix='gei',
                          save_format='png'):
# for batch in datagen.flow(x):
#     i += 1
#     print(type(batch))
#     img_list.append(batch)
#     img_xx = img_list[i-1]
#     cv2.imwrite(str(i) + '.png', img_xx)  # store frames

    if i > 4:  # 这个20指出要扩增多少个数据
        break  # otherwise the generator would loop indefinitely
