import glob as gb
from tqdm import tqdm
import numpy as np
from sklearn.model_selection import train_test_split, ShuffleSplit
import tensorflow as tf
from keras.utils import to_categorical
from sklearn.externals import joblib
import matplotlib.pyplot as plt
import math

train_cross_entropy_list = joblib.load('V4_lrn_nm_train_cross_entropy_list.pkl')
validation_cross_entropy_list = joblib.load('V4_lrn_nm_validation_cross_entropy_list.pkl')
train_accuracy_list = joblib.load('V4_lrn_nm_train_accuracy_list.pkl')
validation_accuracy_list = joblib.load('V4_lrn_nm_validation_accuracy_list.pkl')
test_cross_entropy_list_plot = joblib.load('V4_lrn_nm_test_cross_entropy_list_plot.pkl')
test_accuracy_list_plot = joblib.load('V4_lrn_nm_test_accuracy_list_plot.pkl')
num_epoch = 1000

fig = plt.figure(figsize=(15, 15))
ax1 = fig.add_subplot(211)
x = range(num_epoch)
p1, = ax1.plot(x, train_cross_entropy_list, "--", markersize=2, label="Train Cross Entropy")
p2, = ax1.plot(x, validation_cross_entropy_list, "--", markersize=2, label="Validation Cross Entropy")
handles, labels = ax1.get_legend_handles_labels()
ax1.set_ylabel('Cross Entropy')
ax1.set_xlabel('Epoch')
ax1.set_title(
    "|Last Train Cross Entropy:%.3f" % train_cross_entropy_list[-1] + "|Last Validation Cross Entropy:%.3f" %
    validation_cross_entropy_list[-1] + "|Test Cross Entropy:%.3f" % test_cross_entropy_list_plot[0])
ax1.legend(handles[::-1], labels[::-1])

ax2 = fig.add_subplot(212)
p3, = ax2.plot(x, train_accuracy_list, "--", markersize=2, label="Train Accuracy")
p4, = ax2.plot(x, validation_accuracy_list, "--", markersize=2, label="Validation Accuracy")
handles1, labels1 = ax2.get_legend_handles_labels()
ax2.set_ylabel('Accuracy')
ax2.set_xlabel('Epoch')
ax2.set_title(
    "|Last Train Accuracy:" + str(train_accuracy_list[-1]) + "|Last Validation Accuracy:" + str(
        validation_accuracy_list[-1]) + "|Test Accuracy: %.5f" %
    test_accuracy_list_plot[0])
ax2.legend(handles1[::-1], labels1[::-1])
plt.savefig("GEINet_v1_lre-05_300epoch.png")
plt.show()
