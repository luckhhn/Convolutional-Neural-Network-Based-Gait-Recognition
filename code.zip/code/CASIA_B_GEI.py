# -*- coding: utf-8 -*-
"""
Created on Thu Jul  13 13:12:20 2018

@author: Yuhao Ye
"""
import os
import numpy as np
import cv2
import glob as gb
import matplotlib.pyplot as plt

# rootDir = 'D:\\AI下学期\\Gait_Database\\test'
rootDir = 'D:\\AI2thsemester\\Gait_Database\\GaitDatasetB-silh'
gait_video_path_length = len("D:\\AI2thsemester\\Gait_Database\\GaitDatasetB-silh\\001\\001\\nm-01\\000")
# print(gait_video_path_length)

path_list = []


def path_generator(rootDir):
    count = 0
    for root, dirs, files in os.walk(rootDir, topdown=False):
        for name in dirs:
            if len(os.path.join(root, name)) == gait_video_path_length and os.path.join(root, name)[-2] == "9" and \
                    os.path.join(root, name)[-8] == "m":
                count += 1
                path_list.append(os.path.join(root, name))
                # print(os.path.join(root, name))
    print(count, "Gait Videos in Total")


def visitDir(path):
    if not os.path.isdir(path):
        print('Error: "', path, '" is not a directory or does not exist.')
        return
    else:
        global num
        try:
            for lists in os.listdir(path):
                sub_path = os.path.join(path, lists)
                num += 1
                # print('No.', x, ' ', sub_path)
                if os.path.isdir(sub_path):
                    visitDir(sub_path)
        except:
            pass


# count the number of foreground pixels in
# the silhouette in each frame over time
def pixels_sum(image, height, width):
    sum = 0
    for heights in range(height):
        for widths in range(width):
            if image[heights, widths] == 255:
                sum += 1
    return sum


def find_dis_edge_to_head(image, height, width):
    flag_of_top = 0
    #     height_of_silhouette = 0
    # Search row by row for the top point of the head
    for heights in range(height):
        for widths in range(width):
            if flag_of_top == 0 and image[heights, widths] == 255:
                edge_to_head_f = heights
                flag_of_top = 1
    return edge_to_head_f


def find_dis_edge_to_feet(image, height, width):
    flag_of_feet = 0
    #     height_of_silhouette = 0
    # Search row by row for the top point of the head
    for heights in range(height):
        for widths in range(width):
            if flag_of_feet == 0 and image[image.shape[0] - heights, image.shape[1] - widths] == 255:
                edge_to_feet_f = heights
                flag_of_feet = 1
    return edge_to_feet_f


path_generator(rootDir)

for index in range(len(path_list)):
    num = 0
    visitDir(path_list[index])
    print(path_list[index])
    print("index", index)
    img_path = gb.glob(path_list[index] + "\\*.png")

    binary_silhouette_crop_list = []  # For storing all binary_silhouette frames of one gait video
    cx_list = []  # For storing all x coordinate of centroid
    cx_right_list = []  # For storing all (width-cx)
    edge_to_head_list = []
    edge_to_feet_list = []
    img_list = []
    foreground_pixels_list = []
    gait_period_flag_value_list = []
    gait_period_flag_list = []
    gait_period_flag_plot_list = []
    one_gait_period_img_list = []
    gait_period_flag_real_index_list = []
    error_index_list = []
    count = 0

    for path in img_path:
        count += 1
        if count > 4 and count < (num - 4):
            img = cv2.imread(path)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            img_list.append(img)
            foreground_pixels = pixels_sum(img, img.shape[0], img.shape[1])
            foreground_pixels_list.append(foreground_pixels)
            # print(foreground_pixels)
    for i in range(len(foreground_pixels_list) - 5):
        if foreground_pixels_list[i + 3] < foreground_pixels_list[i + 2] and foreground_pixels_list[i + 3] < \
                foreground_pixels_list[i + 1] and foreground_pixels_list[i + 3] < foreground_pixels_list[i + 4] and \
                foreground_pixels_list[i + 3] < foreground_pixels_list[i + 5]:
            gait_period_flag_value_list.append(foreground_pixels_list[i + 3])
            gait_period_flag_list.append(i)
    for i in range(len(gait_period_flag_value_list)):
        gait_period_flag_real_index_list.append(gait_period_flag_list[i] + 3)

    if len(gait_period_flag_real_index_list) < 3:
        error_index_list.append("Error! Can not find at least one whole gait period in this path: " + path_list[index])
    else:
        print("gait_period_flag_real_index_list", gait_period_flag_real_index_list)

        # gait_period_flag_plot_list.append(i+4)
        print(gait_period_flag_list)
        one_gait_period_img_list = (img_list[gait_period_flag_list[0] + 3:gait_period_flag_list[2] + 3])
        print("Selected frames: ", len(img_list))
        print("One Gait Period Has: ", len(one_gait_period_img_list), "frames")
        plt.figure(figsize=(15, 7))
        x = range(len(foreground_pixels_list))
        print(x)
        x1 = gait_period_flag_real_index_list
        print(x1)
        y = foreground_pixels_list
        # x1 = gait_period_flag_plot_list
        y1 = gait_period_flag_value_list
        plt.title("One Gait Period Has: " + str(len(one_gait_period_img_list)) + " Frames", fontsize=20)
        plt.xlabel("Frames", fontsize=20)
        plt.ylabel("Pixels", fontsize=20)
        plt.xticks(fontsize=20)
        plt.yticks(fontsize=20)
        plt.scatter(x, y, s=80)  # 绘制散点图，透明度为0.6（这样颜色浅一点，比较好看）
        plt.scatter(x1, y1, c='red', marker='x', s=150)  # 绘制散点图，透明度为0.6（这样颜色浅一点，比较好看）
        # plt.scatter(x1, y1, c='red', marker='x', alpha=0.6, s=150)  # 绘制散点图，透明度为0.6（这样颜色浅一点，比较好看）
        plt.savefig('C:\\Users\\叶雨豪\\Dropbox\\Dissertation\\hand_in\\pixel_graph\\' + str(index) + '.png')
        plt.close()
        # plt.show()

        # For getting Centroid of binary_silhouette
        for i in range(len(one_gait_period_img_list)):
            gait_period_frame = one_gait_period_img_list[i]
            m = cv2.moments(gait_period_frame)  # moment
            cx, cy = m['m10'] / m['m00'], m['m01'] / m['m00']  # Centroid of binary_silhouette
            cx = int(cx)  # For Normalise & Align
            cx_right = gait_period_frame.shape[1] - cx
            cx_right_list.append(cx_right)
            cx_list.append(cx)
            edge_to_head = find_dis_edge_to_head(gait_period_frame, gait_period_frame.shape[0],
                                                 gait_period_frame.shape[1])
            edge_to_feet = find_dis_edge_to_head(gait_period_frame, gait_period_frame.shape[0],
                                                 gait_period_frame.shape[1])
            edge_to_head_list.append(edge_to_head)
            edge_to_feet_list.append(edge_to_feet)
        cx_left_min = cx_list[cx_list.index(min(cx_list))]
        cx_right_min = cx_right_list[cx_right_list.index(min(cx_right_list))]
        edge_to_head_min = edge_to_head_list[edge_to_head_list.index(min(edge_to_head_list))]
        edge_to_feet_min = edge_to_feet_list[edge_to_feet_list.index(min(edge_to_feet_list))]
        min_dis = min(cx_right_min, cx_left_min)
        print("Minimum distance of all frames from centroid to left edge: ", cx_left_min)
        print("Minimum distance of all frames from centroid to right edge: ", cx_right_min)
        print("Minimum distance of all frames from top dege to subjects' heads: ", edge_to_head_min)
        print("Minimum distance of all frames from bottom dege to subjects' feet: ", edge_to_feet_min)

        # Crop according to centroid of binary_silhouette
        for i in range(len(one_gait_period_img_list)):
            cx = cx_list[i]
            gait_period_frame = one_gait_period_img_list[i]
            crop = gait_period_frame[edge_to_head_min:img.shape[0] - edge_to_feet_min + 5, cx - min_dis:cx + min_dis]
            #     cv2.namedWindow('Crop', flags=0)
            #     cv2.imshow('Crop', crop)
            #     cv2.waitKey()
            crop = crop.astype(np.uint64)
            binary_silhouette_crop_list.append(crop)
        # cv2.destroyAllWindows()
        for i in range(len(one_gait_period_img_list)):
            if i == 0:
                gei_sum = binary_silhouette_crop_list[0]
                # print("gei_sum", gei_sum.shape)
                # print("gei_sum", binary_silhouette_crop_list[1].shape)
            if i > 0:
                gei_sum = cv2.add(gei_sum, binary_silhouette_crop_list[i])
        gei = gei_sum / len(one_gait_period_img_list)
        gei = gei.astype(np.uint8)
        # cv2.imwrite('C:\\Users\\叶雨豪\\Dropbox\\Dissertation\\hand_in\\GEI\\' + str(index) + '.png', gei)
        cv2.imwrite('D:/AI2thsemester/GEI/' + str(index) + '.png', gei)

        # cv2.namedWindow('GEI', flags=0)
        # cv2.imshow('GEI', gei)
        # cv2.waitKey()
        print("GEI.shape: ", gei.shape)
        # cv2.destroyAllWindows()

for i in range(len(error_index_list)):
    print(error_index_list[i])